import java.util.Scanner;
class Library
{
    String bookName, AuthorNames;
    int bookNo, NoofPages;
    double price;
    public void addBook() 
	{
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter Book Name: ");
        bookName = sc.nextLine();
        System.out.print("Enter Book Number: ");
        bookNo = sc.nextInt();
        System.out.print("Enter Number of Pages: ");
        NoofPages = sc.nextInt();
        System.out.print("Enter Price: ");
        price = sc.nextDouble();
        System.out.print("Enter Author Name: ");
        AuthorNames = sc.next();
    }
    public void showBookInfo() 
	{
        System.out.println("Book Name: " + bookName);
        System.out.println("Book Number: " + bookNo);
        System.out.println("Number of Pages: " + NoofPages);
        System.out.println("Price: " + price);
        System.out.println("Author Name: " + AuthorNames);
    }
    public static void main(String[] args) 
	{
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the number of books: ");
        int n = sc.nextInt();
        Library[] books = new Library[n];
        for (int i = 0; i < n; i++) 
		{
            books[i] = new Library();
            System.out.println("Enter details of Book " + (i + 1) + ":");
            books[i].addBook();
		}
        System.out.println("Details of all books:");
        for (int i = 0; i < n; i++) 
		{
            System.out.println("Book " + (i + 1) + ":");
            books[i].showBookInfo();
        }
    }
}