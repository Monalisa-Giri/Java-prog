import java.lang.*;
import java.util.Scanner;
import java.lang.Math;

class Number {
    private int num;

    public void setNum(int num) {
        this.num = num;
    }

    public void displayNum() {
        System.out.println("Number: " + num);
    }

    public int factorial() {
        if (num < 0) {
            return -1; 
        }

        int res = 1;
        for (int i = 1; i <= num; i++) {
            res *= i;
        }
        return res;
    }
	
    public boolean isPrime() {
        if (num <= 1) {
            return false;
        }

        for (int i = 2; i <= Math.sqrt(num); i++) {
            if (num % i == 0) {
                return false;
            }
        }
        return true;
    }

    public int sumOfDigit() {
        int numCopy = num;
        int tot = 0;
        while (numCopy != 0) {
            tot += numCopy % 10;
            numCopy /= 10;
        }
        return tot;
    }

    public int reverseNum() {
        int numCopy = num;
        int reversed = 0;
        while (numCopy != 0) {
            int digit = numCopy % 10;
            reversed = reversed * 10 + digit;
            numCopy /= 10;
        }
        return reversed;
    }

    public static void main(String[] args) {
		int n;
		Scanner in = new Scanner (System.in);
		System.out.println("Enter number:");
        n=in.nextInt();
		Number num = new Number();
        num.setNum(n);
		num.displayNum();
        int factorialResult = num.factorial();
        if (factorialResult != -1) {
            System.out.println("Factorial: " + factorialResult);
        } else {
            System.out.println("Factorial is undefined for negative numbers.");
        }
        boolean isPrime = num.isPrime();
        System.out.println("Prime: " + (isPrime ? "Yes" : "No"));
        int sumOfDigits = num.sumOfDigit();
        System.out.println("Sum of Digits: " + sumOfDigits);
        int reversedNumber = num.reverseNum();
        System.out.println("Reversed Number: " + reversedNumber);
    }
}